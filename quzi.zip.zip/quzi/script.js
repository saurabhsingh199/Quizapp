document.getElementById("themeToggle").addEventListener("change", function () {
  document.body.classList.toggle("light");
});